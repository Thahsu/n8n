from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
import time
import os
import pyautogui
import tempfile
import base64
import requests

# === URL Google Apps Script của bạn ===
UPLOAD_URL = "https://script.google.com/macros/s/AKfycbxzxhKavSggC7DQPxiRmyJwTqcMGhQX5jmLiznluXojmlgY0z0ZHeRD91VT5D7gQ4IO3A/exec"

# === Tên thư mục dùng cho tất cả ảnh trong phiên chạy này ===
FOLDER_NAME = datetime.now().strftime("GoogleCapture_%Y-%m-%d_%H-%M-%S")

def capture_google(keyword, lang_code, label):
    # Tạo ảnh tạm
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"screenshot_{label}_{timestamp}.png"
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
    temp_path = temp_file.name
    temp_file.close()

    # Mở trình duyệt ẩn danh
    options = webdriver.ChromeOptions()
    options.add_argument("--incognito")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    driver = webdriver.Chrome(options=options)
    driver.maximize_window()
    driver.get(f"https://www.google.com.vn?hl={lang_code}")
    time.sleep(3)

    # Gõ từ khoá
    search_box = driver.find_element(By.NAME, "q")
    search_box.send_keys(keyword)
    time.sleep(0.2)
    search_box.send_keys(" ")
    search_box.send_keys(Keys.BACKSPACE)
    time.sleep(2.5)

    # Đẩy popup nếu có
    try:
        WebDriverWait(driver, 3).until(EC.presence_of_element_located((By.CSS_SELECTOR, "div[role='dialog']")))
        driver.execute_script("""
            let popup = document.querySelector("div[role='dialog']");
            if (popup) {
                popup.style.position = "fixed";
                popup.style.top = "0";
                popup.style.left = "auto";
                popup.style.right = "0";
                popup.style.bottom = "auto";
                popup.style.zIndex = "9999";
                popup.style.transform = "scale(0.7) translate(-50px, 10px)";
                popup.style.maxWidth = "240px";
                popup.style.maxHeight = "120px";
                popup.style.overflow = "hidden";
                popup.style.boxShadow = "0 0 8px rgba(0,0,0,0.3)";
            }
        """)
        time.sleep(1)
    except:
        print("⚠️ Không tìm thấy popup hoặc không cần di chuyển")

    # Chụp ảnh toàn màn hình
    screenshot = pyautogui.screenshot()
    screenshot.save(temp_path)
    driver.quit()

    # Upload ảnh
    try:
        with open(temp_path, "rb") as f:
            encoded_image = base64.b64encode(f.read()).decode("utf-8")

        response = requests.post(UPLOAD_URL, data={
            "file": encoded_image,
            "name": filename,
            "folder": FOLDER_NAME  # gửi tên thư mục duy nhất cho cả phiên
        })

        print(f"✅ Upload thành công ({label}):", response.text)
    except Exception as e:
        print("❌ Upload thất bại:", e)

    os.remove(temp_path)

# === CHỤP ẢNH GOOGLE ===
capture_google("bầu hiển ", "vi", "tieng_viet_codau")
capture_google("bầu hiển ", "en", "tieng_anh_codau")
capture_google("bau hien ", "vi", "tieng_viet_khongdau")
capture_google("bau hien ", "en", "tieng_anh_khongdau")
