from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
import time
import os
import tempfile
import base64
import requests

# === URL Apps Script của bạn ===
UPLOAD_URL = "https://script.google.com/macros/s/AKfycbxzxhKavSggC7DQPxiRmyJwTqcMGhQX5jmLiznluXojmlgY0z0ZHeRD91VT5D7gQ4IO3A/exec"

# === Tên thư mục Drive chung cho cả phiên ===
FOLDER_NAME = datetime.now().strftime("GoogleCapture_%Y-%m-%d_%H-%M-%S")

def capture_google(keyword, lang_code, label):
    # Tạo file tạm
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"screenshot_{label}_{timestamp}.png"
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
    temp_path = temp_file.name
    temp_file.close()

    # Khởi tạo trình duyệt
    options = webdriver.ChromeOptions()
    options.add_argument("--headless")  # CHẾ ĐỘ KHÔNG MÀN HÌNH
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    driver = webdriver.Chrome(options=options)

    # Truy cập Google
    driver.get(f"https://www.google.com.vn?hl={lang_code}")
    time.sleep(2)

    search_box = driver.find_element(By.NAME, "q")
    search_box.send_keys(keyword)
    time.sleep(0.2)
    search_box.send_keys(" ")
    search_box.send_keys(Keys.BACKSPACE)
    time.sleep(2.5)

    # Chụp ảnh màn trình duyệt
    driver.save_screenshot(temp_path)
    driver.quit()

    # Upload
    try:
        with open(temp_path, "rb") as f:
            encoded_image = base64.b64encode(f.read()).decode("utf-8")

        response = requests.post(UPLOAD_URL, data={
            "file": encoded_image,
            "name": filename,
            "folder": FOLDER_NAME
        })
        print(f"✅ Upload thành công ({label}):", response.text)
    except Exception as e:
        print("❌ Upload thất bại:", e)

    os.remove(temp_path)
# === CHỤP ẢNH GOOGLE ===
capture_google("bầu hiển ", "vi", "tieng_viet_codau")
capture_google("bầu hiển ", "en", "tieng_anh_codau")
capture_google("bầu hiển", "vi", "tieng_viet_codau")
capture_google("bầu hiển", "en", "tieng_anh_codau")
capture_google("bau hien ", "vi", "tieng_viet_khongdau")
capture_google("bau hien ", "en", "tieng_anh_khongdau")
capture_google("bau hien", "vi", "tieng_viet_khongdau")
capture_google("bau hien", "en", "tieng_anh_khongdau")
capture_google("câu lạc bộ bầu hiển ", "vi", "tieng_viet_codau")
capture_google("câu lạc bộ bầu hiển ", "en", "tieng_viet_codau")
capture_google("câu lạc bộ bầu hiển", "vi", "tieng_viet_codau")
capture_google("câu lạc bộ bầu hiển", "en", "tieng_viet_codau")
capture_google("chủ tịch ngân hàng shb ", "vi", "tieng_viet_codau")
capture_google("chủ tịch ngân hàng shb ", "en", "tieng_viet_codau")
capture_google("chủ tịch ngân hàng shb", "vi", "tieng_viet_codau")
capture_google("chủ tịch ngân hàng shb", "en", "tieng_viet_codau")
capture_google("chủ tịch shb ", "vi", "tieng_viet_codau")
capture_google("chủ tịch shb ", "en", "tieng_viet_codau")
capture_google("chủ tịch shb", "vi", "tieng_viet_codau")
capture_google("chủ tịch shb", "en", "tieng_viet_codau")
capture_google("clb bầu hiển ", "vi", "tieng_viet_codau")
capture_google("clb bầu hiển ", "en", "tieng_viet_codau")
capture_google("clb bầu hiển", "vi", "tieng_viet_codau")
capture_google("clb bầu hiển", "en", "tieng_viet_codau")
capture_google("do quang hien ", "vi", "tieng_viet_khongdau")
capture_google("do quang hien ", "en", "tieng_anh_khongdau")
capture_google("do quang hien", "vi", "tieng_viet_khongdau")
capture_google("do quang hien", "en", "tieng_anh_khongdau")
capture_google("đỗ quang hiển ", "vi", "tieng_viet_codau")
capture_google("đỗ quang hiển ", "en", "tieng_viet_codau")
capture_google("đỗ quang hiển", "vi", "tieng_viet_codau")
capture_google("đỗ quang hiển", "en", "tieng_viet_codau")
capture_google("đội bóng bầu hiển ", "vi", "tieng_viet_codau")
capture_google("đội bóng bầu hiển ", "en", "tieng_viet_codau")
capture_google("đội bóng bầu hiển", "vi", "tieng_viet_codau")
capture_google("đội bóng bầu hiển", "en", "tieng_viet_codau")
capture_google("giám đốc ngân hàng shb ", "vi", "tieng_viet_codau")
capture_google("giám đốc ngân hàng shb ", "en", "tieng_viet_codau")
capture_google("giám đốc ngân hàng shb", "vi", "tieng_viet_codau")
capture_google("giám đốc ngân hàng shb", "en", "tieng_viet_codau")
capture_google("giám đốc shb ", "vi", "tieng_viet_codau")
capture_google("giám đốc shb ", "en", "tieng_viet_codau")
capture_google("giám đốc shb", "vi", "tieng_viet_codau")
capture_google("giám đốc shb", "en", "tieng_viet_codau")
capture_google("t&t group ", "vi", "tieng_viet_khongdau")
capture_google("t&t group ", "en", "tieng_viet_khongdau")
capture_google("t&t group", "vi", "tieng_vie_khongdau")
capture_google("t&t group", "en", "tieng_viet_khongdau")
capture_google("đỗ vinh quang ", "vi", "tieng_viet_codau")
capture_google("đỗ vinh quang ", "en", "tieng_viet_codau")
capture_google("đỗ vinh quang", "vi", "tieng_viet_codau")
capture_google("đỗ vinh quang", "en", "tieng_viet_codau")
capture_google("do vinh quang ", "vi", "tieng_viet_khongdau")
capture_google("do vinh quang ", "en", "tieng_anh_khongdau")
capture_google("do vinh quang", "vi", "tieng_viet_khongdau")
capture_google("do vinh quang", "en", "tieng_anh_khongdau")
capture_google("đỗ mỹ linh ", "vi", "tieng_viet_codau")
capture_google("đỗ mỹ linh ", "en", "tieng_viet_codau")
capture_google("đỗ mỹ linh", "vi", "tieng_viet_codau")
capture_google("đỗ mỹ linh", "en", "tieng_viet_codau")
capture_google("do my linh ", "vi", "tieng_viet_khongdau")
capture_google("do my linh ", "en", "tieng_anh_khongdau")
capture_google("do my linh", "vi", "tieng_viet_khongdau")
capture_google("do my linh", "en", "tieng_anh_khongdau")